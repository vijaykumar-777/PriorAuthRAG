/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ViewType, ToastMessage } from './types.ts';
import { Header } from './components/Header.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { Toast } from './components/Toast.tsx';
import { ApiDocsModal } from './components/ApiDocsModal.tsx';
import { ActiveAuthorizationsView } from './components/ActiveAuthorizationsView.tsx';
import { GuidelineInspectorView } from './components/GuidelineInspectorView.tsx';
import { CoverageRulesView } from './components/CoverageRulesView.tsx';
import { MedicalPoliciesView } from './components/MedicalPoliciesView.tsx';
import { TOCIndexView } from './components/TOCIndexView.tsx';
import { ClinicalAuditLogView } from './components/ClinicalAuditLogView.tsx';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('prior-auth-dashboard');
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [isApiDocsOpen, setIsApiDocsOpen] = useState(false);

  const showToast = (message: string, icon = 'check_circle', type: ToastMessage['type'] = 'success') => {
    setToast({
      id: `${Date.now()}-${Math.random()}`,
      message,
      icon,
      type,
    });
  };

  const handleNavigate = (view: ViewType) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bg-background min-h-screen text-on-surface font-sans antialiased flex flex-col selection:bg-primary-fixed selection:text-on-primary-fixed">
      {/* Fixed Global Header */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenApiDocs={() => setIsApiDocsOpen(true)}
      />

      {/* Fixed Sidebar */}
      <Sidebar
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {/* Main Viewport Content Area (Offset by sidebar width 64 = 16rem = 256px, and header height 16 = 4rem = 64px) */}
      <div className="pl-64 flex-1 flex flex-col">
        <main className="w-full pt-16 min-h-screen bg-background flex flex-col">
          {currentView === 'prior-auth-dashboard' && (
            <ActiveAuthorizationsView
              onShowToast={showToast}
              onNavigateToToc={() => handleNavigate('toc-index')}
            />
          )}

          {currentView === 'clinical-guidelines-rag' && (
            <GuidelineInspectorView onShowToast={showToast} />
          )}

          {currentView === 'coverage-rules' && (
            <CoverageRulesView onShowToast={showToast} />
          )}

          {currentView === 'medical-policies' && (
            <MedicalPoliciesView onShowToast={showToast} />
          )}

          {currentView === 'toc-index' && (
            <TOCIndexView
              onShowToast={showToast}
              onNavigateToInspector={() => handleNavigate('clinical-guidelines-rag')}
            />
          )}

          {currentView === 'audit-trail' && (
            <ClinicalAuditLogView onShowToast={showToast} />
          )}
        </main>
      </div>

      {/* Global Toast Notification */}
      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* API Documentation Modal */}
      <ApiDocsModal
        isOpen={isApiDocsOpen}
        onClose={() => setIsApiDocsOpen(false)}
      />
    </div>
  );
}
